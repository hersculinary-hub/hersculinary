'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';

const NAV_ITEMS = [
  { href: '/admin/products', label: 'Produk', icon: '🍱' },
  { href: '/admin/categories', label: 'Kategori', icon: '🗂️' },
  { href: '/pos', label: 'Kasir (POS)', icon: '🧾' },
  { href: '/', label: 'Lihat Katalog', icon: '🌐' }
];

export default function AdminShell({ children, title }) {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/admin/login');
    router.refresh();
  }

  return (
    <div className="min-h-screen bg-cream md:flex">
      <aside className="sticky top-0 z-30 flex items-center justify-between bg-brandRedDark px-4 py-3 text-white md:h-screen md:w-60 md:flex-col md:items-stretch md:justify-start md:py-6">
        <Link href="/admin/products" className="font-display text-2xl">
          HerS <span className="text-brandGold">Admin</span>
        </Link>

        <nav className="hidden gap-1 md:mt-8 md:flex md:flex-1 md:flex-col">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`rounded-lg px-3 py-2.5 text-sm font-bold transition ${
                pathname === item.href ? 'bg-white text-brandRedDark' : 'text-white/85 hover:bg-white/10'
              }`}
            >
              <span className="mr-2">{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>

        <button
          onClick={handleLogout}
          className="hidden rounded-lg px-3 py-2.5 text-left text-sm font-bold text-white/85 hover:bg-white/10 md:block"
        >
          🚪 Keluar
        </button>

        <button onClick={handleLogout} className="text-sm font-bold md:hidden">
          Keluar
        </button>
      </aside>

      <div className="flex-1">
        <div className="flex gap-1 overflow-x-auto border-b border-brandBrown/10 bg-white px-2 py-2 md:hidden">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`whitespace-nowrap rounded-lg px-3 py-2 text-xs font-bold ${
                pathname === item.href ? 'bg-brandRed text-white' : 'text-brandBrown/70'
              }`}
            >
              {item.icon} {item.label}
            </Link>
          ))}
        </div>

        <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-8">
          {title && <h1 className="mb-6 font-display text-2xl text-brandBrown sm:text-3xl">{title}</h1>}
          {children}
        </main>
      </div>
    </div>
  );
}
