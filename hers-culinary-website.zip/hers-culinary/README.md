# HerS Culinary — Website Katalog + Admin + Kasir (POS)

Website lengkap untuk toko online **HerS Culinary** (frozen food & kopi pilihan), terdiri dari 3 bagian:

1. **Katalog publik** (`/`) — pelanggan bisa lihat produk per kategori/sub kategori, cari produk, pesan via WhatsApp, dan setiap produk punya halaman + tombol bagikan ke sosial media.
2. **Admin** (`/admin`) — kelola produk (tambah/edit/hapus) dan kategori/sub kategori (tambah/edit/hapus), dilindungi login.
3. **Kasir / POS** (`/pos`) — buat transaksi, hitung total otomatis, simpan sebagai invoice, dan unduh invoice dalam bentuk **PDF**. Bisa dipakai dari PC maupun HP.

Semua halaman **responsif** (otomatis menyesuaikan tampilan PC dan HP).

---

## 1. Login default

| Username | Password |
|---|---|
| admin | hers123 |

⚠️ **Wajib diganti** lewat environment variable `ADMIN_USERNAME` / `ADMIN_PASSWORD` sebelum website dipakai untuk umum (lihat langkah deploy di bawah).

---

## 2. Menjalankan di komputer sendiri (opsional, sebelum deploy)

Butuh [Node.js](https://nodejs.org) versi 18 ke atas sudah terpasang.

```bash
npm install
cp .env.example .env.local
# buka .env.local, isi ADMIN_USERNAME, ADMIN_PASSWORD, AUTH_SECRET bebas (string acak)
npm run dev
```

Buka `http://localhost:3000` untuk katalog, `http://localhost:3000/admin` untuk admin, `http://localhost:3000/pos` untuk kasir.

Saat dijalankan secara lokal tanpa Vercel KV, data disimpan sementara di file `.data/db.json` — cukup untuk mencoba-coba, tapi **tidak dipakai saat sudah online di Vercel** (lihat langkah 4).

---

## 3. Deploy ke Vercel

1. Upload folder project ini ke GitHub (buat repository baru, push semua file).
2. Buka [vercel.com](https://vercel.com) → **Add New Project** → pilih repository tadi → **Deploy**.
3. Setelah deploy pertama (boleh gagal dulu karena env variable belum diisi — tidak apa-apa), buka **Project → Settings → Environment Variables** dan tambahkan:

   | Key | Value |
   |---|---|
   | `ADMIN_USERNAME` | username pilihanmu |
   | `ADMIN_PASSWORD` | password pilihanmu (yang kuat) |
   | `AUTH_SECRET` | teks acak panjang, bebas (misal hasil generate dari [randomkeygen.com](https://randomkeygen.com)) |

4. **Wajib**: tambahkan **Vercel KV** supaya data produk/kategori/invoice tersimpan permanen (server Vercel bersifat sementara/tidak punya penyimpanan file permanen):
   - Buka tab **Storage** di dashboard project Vercel → **Create Database** → pilih **KV** (Upstash Redis) → hubungkan (**Connect**) ke project ini.
   - Vercel otomatis menambahkan `KV_REST_API_URL` dan `KV_REST_API_TOKEN` ke environment variables — tidak perlu diisi manual.
5. Buka tab **Deployments** → klik **Redeploy** pada deployment terakhir supaya environment variable baru terpakai.
6. Selesai! Website bisa diakses dari PC maupun HP di domain yang diberikan Vercel (atau domain sendiri kalau sudah dihubungkan).

---

## 4. Menambahkan foto produk

Form tambah/edit produk di admin meminta **URL gambar**, bukan upload file langsung (supaya project tetap ringan dan gratis di Vercel). Caranya:

- Upload foto produk ke layanan gratis seperti [imgur.com](https://imgur.com) atau Google Drive (atur jadi "Siapa saja yang punya link"), lalu salin link gambarnya (harus link langsung ke file gambar, bukan link halaman).
- Tempel link tersebut ke kolom **URL Gambar Produk** saat tambah/edit produk.

*(Kalau nanti mau upload foto langsung dari komputer/HP tanpa link eksternal, project ini bisa ditingkatkan dengan menambahkan **Vercel Blob** — beri tahu saya kalau mau saya siapkan.)*

---

## 5. Fitur per halaman

### Katalog (`/`)
- Banner utama pakai gambar promosi yang kamu kirim (`public/banner.png`) — bisa diganti kapan saja dengan mengganti file itu.
- Filter kategori & sub kategori, kolom pencarian produk.
- Tombol **Pesan via WhatsApp** otomatis mengisi pesan dengan nama & harga produk.
- Tombol **Bagikan** di tiap produk → WhatsApp, Facebook, X (Twitter), dan salin tautan.
- Halaman detail produk (`/produk/[id]`) sebagai tautan yang dibagikan ke sosial media.

### Admin (`/admin`)
- **Produk**: tabel semua produk, tombol tambah/edit/hapus, serta tombol bagikan langsung dari daftar.
- **Kategori**: tambah/edit/hapus kategori, dan di dalam tiap kategori bisa tambah/edit/hapus sub kategori.

### Kasir / POS (`/pos`)
- Pilih produk dari katalog (dengan pencarian), atur jumlah, beri diskon, pilih metode pembayaran.
- Nomor invoice dibuat otomatis (format `HC-YYYYMMDD-0001`).
- Klik **Buat & Unduh Invoice (PDF)** → invoice tersimpan dan file PDF langsung terunduh, bisa dibuka/print dari PC maupun HP.

---

## 6. Struktur folder singkat

```
app/                    → semua halaman (Next.js App Router)
  page.js               → katalog publik
  produk/[id]/page.js   → halaman detail produk (untuk dibagikan)
  admin/                → semua halaman admin (dilindungi login)
  pos/page.js            → halaman kasir
  api/                  → backend (categories, products, invoices, auth)
components/             → komponen UI yang dipakai berulang
lib/                    → logika data (categories.js, products.js, invoices.js),
                          auth.js (login), store.js (penyimpanan data), pdfInvoice.js (pembuat PDF)
public/banner.png       → gambar banner di halaman utama
```

---

## 7. Catatan keamanan

- Ganti `ADMIN_PASSWORD` dan `AUTH_SECRET` sebelum website dipakai untuk transaksi sungguhan.
- Halaman `/admin/*` dan `/pos/*` otomatis diarahkan ke halaman login kalau belum masuk.
- Saat ini hanya ada satu akun admin (dipakai bersama untuk admin & kasir). Kalau butuh banyak akun kasir dengan hak akses berbeda, beri tahu saya — bisa ditambahkan.
